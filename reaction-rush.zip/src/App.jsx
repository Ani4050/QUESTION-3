import { useState, useRef, useEffect, useCallback } from "react";

const COLORS = ["#ff2e63", "#ff7a1a", "#ffd400", "#9dff00", "#00ff85", "#00f0ff", "#2d8bff", "#8a5cff", "#e63cff", "#ff5fa8"];
const SPEEDS = { Slow: { ms: 900, mult: 1 }, Medium: { ms: 520, mult: 1.5 }, Fast: { ms: 260, mult: 2 } };
const N = 10;

const css = `
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;800&family=Chakra+Petch:wght@400;600&display=swap');
.rr{min-height:100vh;background:radial-gradient(ellipse at 50% 0%,#1a0b3d 0%,#070713 60%);color:#e8eaff;font-family:'Chakra Petch',system-ui,sans-serif;padding:16px;box-sizing:border-box}
.rr *{box-sizing:border-box}
.rr .wrap{max-width:980px;margin:0 auto;display:flex;flex-direction:column;gap:16px}
.rr h1{font-family:Orbitron,sans-serif;font-weight:800;font-size:clamp(22px,5vw,40px);margin:0;text-align:center;letter-spacing:.06em;color:#fff;text-shadow:0 0 8px #00f0ff,0 0 24px #e63cff}
.rr .sub{text-align:center;color:#8f93c9;margin:4px 0 0;font-size:14px}
.rr .panel{background:rgba(16,16,40,.85);border:1px solid #2b2b66;border-radius:14px;padding:16px;box-shadow:0 0 22px rgba(138,92,255,.15)}
.rr .leds{display:grid;grid-template-columns:repeat(10,1fr);gap:10px}
@media(max-width:640px){.rr .leds{grid-template-columns:repeat(5,1fr)}}
.rr .slot{display:flex;flex-direction:column;align-items:center;gap:6px}
.rr .tag{font-size:11px;height:14px;color:#00f0ff;font-weight:600}
.rr .led{width:100%;aspect-ratio:1;max-width:72px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:Orbitron,sans-serif;font-weight:800;font-size:clamp(14px,3vw,20px);background:#14142e;border:2px solid #2b2b66;color:#4a4d8a;transition:background .08s,box-shadow .08s,transform .08s,color .08s}
.rr .led.on{color:#000;transform:scale(1.12)}
.rr .led.tgt{border-style:dashed;border-color:#00f0ff;color:#00f0ff}
.rr .row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.rr .lbl{font-size:13px;color:#8f93c9;margin-bottom:6px}
.rr .chip,.rr .btn{font-family:inherit;font-weight:600;cursor:pointer;border-radius:10px;border:1px solid #3a3a85;background:#14142e;color:#cfd3ff;padding:9px 14px;font-size:14px;transition:all .15s}
.rr .chip:hover:not(:disabled){border-color:#00f0ff;color:#fff}
.rr .chip.sel{background:#00f0ff;color:#001018;border-color:#00f0ff;box-shadow:0 0 14px #00f0ff88}
.rr .chip.num{width:40px;padding:9px 0;text-align:center}
.rr button:disabled{opacity:.35;cursor:not-allowed}
.rr .btn{font-family:Orbitron,sans-serif;letter-spacing:.05em;padding:12px 20px}
.rr .start{background:#00ff85;color:#00180b;border-color:#00ff85;box-shadow:0 0 16px #00ff8566}
.rr .stop{background:#ff2e63;color:#fff;border-color:#ff2e63;box-shadow:0 0 16px #ff2e6388;font-size:18px;padding:14px 34px}
.rr .again{background:#ffd400;color:#1a1400;border-color:#ffd400;box-shadow:0 0 16px #ffd40066}
.rr .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px}
.rr .stat{background:#0c0c22;border:1px solid #2b2b66;border-radius:10px;padding:10px;text-align:center}
.rr .stat b{display:block;font-family:Orbitron,sans-serif;font-size:clamp(18px,4vw,26px);color:#fff;text-shadow:0 0 10px #8a5cff}
.rr .stat span{font-size:12px;color:#8f93c9}
.rr .result{text-align:center;min-height:96px;display:flex;flex-direction:column;justify-content:center;gap:4px}
.rr .big{font-family:Orbitron,sans-serif;font-weight:800;font-size:clamp(34px,9vw,60px);letter-spacing:.1em}
.rr .win{color:#00ff85;text-shadow:0 0 22px #00ff85;animation:pop .35s}
.rr .miss{color:#ff2e63;text-shadow:0 0 22px #ff2e63;animation:shake .35s}
.rr .info{color:#8f93c9;font-size:15px}
@keyframes pop{0%{transform:scale(.6)}70%{transform:scale(1.12)}100%{transform:scale(1)}}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}
@keyframes blink{50%{opacity:.35}}
.rr .blink{animation:blink .6s infinite}
.rr svg{width:100%;height:auto;display:block}
.rr svg text{font-family:'Chakra Petch',sans-serif;fill:#cfd3ff;font-size:13px}
@media(prefers-reduced-motion:reduce){.rr *{animation:none!important;transition:none!important}}
`;

function Box({ x, y, w, h, label, sub, color, lit }) {
  return (
    <g>
      <rect x={x} y={y} width={w} height={h} rx="8" fill={lit ? color + "30" : "#0c0c22"} stroke={color} strokeWidth={lit ? 2.5 : 1.5}
        style={{ filter: lit ? `drop-shadow(0 0 6px ${color})` : "none", transition: "all .15s" }} />
      <text x={x + w / 2} y={y + (sub ? h / 2 - 2 : h / 2 + 5)} textAnchor="middle" fontWeight="600">{label}</text>
      {sub && <text x={x + w / 2} y={y + h / 2 + 14} textAnchor="middle" style={{ fontSize: 10, fill: "#8f93c9" }}>{sub}</text>}
    </g>
  );
}

function Arrow({ d, color = "#6a6fd8", lit }) {
  return <path d={d} fill="none" stroke={lit ? "#fff" : color} strokeWidth={lit ? 2.2 : 1.5} markerEnd="url(#ah)" />;
}

function Circuit({ phase, active, result }) {
  const run = phase === "running", done = phase === "result";
  return (
    <svg viewBox="0 0 760 300" role="img" aria-label="Block diagram of the game circuit">
      <defs>
        <marker id="ah" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#8a8fff" /></marker>
      </defs>
      <Box x={10} y={20} w={150} h={52} label="Clock / Timer" sub="sets LED speed" color="#00f0ff" lit={run} />
      <Box x={250} y={20} w={170} h={52} label="Random LED Selector" sub="picks 1 of 10" color="#e63cff" lit={run} />
      <Box x={510} y={20} w={170} h={52} label="10 LED Outputs" sub={run ? `LED ${active} on` : "idle"} color="#ffd400" lit={run} />
      <Arrow d="M160,46 H248" lit={run} />
      <Arrow d="M420,46 H508" lit={run} />

      <Box x={10} y={120} w={150} h={52} label="Target Selector" sub="1–10 or random" color="#9dff00" lit={run || done} />
      <Box x={250} y={120} w={170} h={52} label="Comparator" sub="target = active ?" color="#ff7a1a" lit={done} />
      <Box x={510} y={120} w={170} h={52} label={done ? (result === "win" ? "WIN" : "MISS") : "Win / Miss"} sub="indicator" color={done ? (result === "win" ? "#00ff85" : "#ff2e63") : "#8a5cff"} lit={done} />
      <Arrow d="M160,146 H248" lit={run || done} />
      <Arrow d="M420,146 H508" lit={done} />
      <Arrow d="M595,72 V90 H335 V118" lit={run} />
      <text x={470} y={86} style={{ fontSize: 10, fill: "#8f93c9" }}>active LED</text>

      <Box x={10} y={230} w={150} h={52} label="Stop Button" sub="Spacebar / tap" color="#ff2e63" lit={done} />
      <Box x={250} y={230} w={170} h={52} label="Reaction Timer" sub="measures in ms" color="#2d8bff" lit={done} />
      <Arrow d="M160,256 H248" lit={done} />
      <Arrow d="M335,230 V174" lit={done} />
      <text x={345} y={206} style={{ fontSize: 10, fill: "#8f93c9" }}>latch</text>
    </svg>
  );
}

export default function ReactionRush() {
  const [sel, setSel] = useState("random");
  const [speed, setSpeed] = useState("Medium");
  const [phase, setPhase] = useState("idle");
  const [active, setActive] = useState(0);
  const [target, setTarget] = useState(0);
  const [result, setResult] = useState(null); // {type,time,hitLed,score}
  const [stats, setStats] = useState({ attempts: 0, hits: 0, best: null, score: 0 });
  const [sound, setSound] = useState(true);

  const timer = useRef(null);
  const phaseRef = useRef("idle");
  const activeRef = useRef(0);
  const targetRef = useRef(0);
  const litAt = useRef(0);
  const audio = useRef(null);
  const soundRef = useRef(true);
  const speedRef = useRef("Medium");
  soundRef.current = sound;
  speedRef.current = speed;

  const beep = useCallback((freq, dur = 0.1, type = "square", vol = 0.05, delay = 0) => {
    if (!soundRef.current) return;
    try {
      if (!audio.current) audio.current = new (window.AudioContext || window.webkitAudioContext)();
      const ctx = audio.current;
      if (ctx.state === "suspended") ctx.resume();
      const o = ctx.createOscillator(), g = ctx.createGain();
      const t0 = ctx.currentTime + delay;
      o.type = type; o.frequency.value = freq;
      g.gain.setValueAtTime(vol, t0);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(ctx.destination);
      o.start(t0); o.stop(t0 + dur);
    } catch (e) { /* audio unavailable */ }
  }, []);

  const clearTimer = () => {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
  };

  useEffect(() => clearTimer, []);

  const setPhaseBoth = (p) => { phaseRef.current = p; setPhase(p); };

  const tick = useCallback(() => {
    let next;
    do { next = 1 + Math.floor(Math.random() * N); } while (next === activeRef.current);
    activeRef.current = next;
    litAt.current = performance.now();
    setActive(next);
    beep(260 + next * 60, 0.05, "square", 0.025);
  }, [beep]);

  const start = useCallback(() => {
    if (phaseRef.current === "running" || timer.current) return; // one game at a time
    const t = sel === "random" ? 1 + Math.floor(Math.random() * N) : sel;
    targetRef.current = t;
    activeRef.current = 0;
    setTarget(t);
    setResult(null);
    setPhaseBoth("running");
    beep(520, 0.12, "triangle", 0.06);
    tick();
    timer.current = setInterval(tick, SPEEDS[speedRef.current].ms);
  }, [sel, tick, beep]);

  const stop = useCallback(() => {
    if (phaseRef.current !== "running") return; // ignore rapid/duplicate presses
    const now = performance.now();
    clearTimer();
    setPhaseBoth("result");
    const hitLed = activeRef.current;
    const hit = hitLed === targetRef.current;
    const time = Math.round(now - litAt.current);
    if (hit) {
      const pts = Math.round(Math.max(50, 1000 - time) * SPEEDS[speedRef.current].mult);
      setResult({ type: "win", time, hitLed, score: pts });
      setStats((s) => ({ attempts: s.attempts + 1, hits: s.hits + 1, best: s.best === null ? time : Math.min(s.best, time), score: s.score + pts }));
      [660, 880, 1320].forEach((f, i) => beep(f, 0.16, "triangle", 0.07, i * 0.09));
    } else {
      setResult({ type: "miss", time, hitLed, score: 0 });
      setStats((s) => ({ ...s, attempts: s.attempts + 1 }));
      beep(130, 0.35, "sawtooth", 0.07);
    }
  }, [beep]);

  const reset = () => {
    clearTimer();
    setPhaseBoth("idle");
    activeRef.current = 0;
    setActive(0); setTarget(0); setResult(null);
    setStats({ attempts: 0, hits: 0, best: null, score: 0 });
    beep(300, 0.1, "triangle", 0.05);
  };

  useEffect(() => {
    const inHw = (e) => e.target && e.target.closest && e.target.closest(".hw");
    const down = (e) => {
      if (inHw(e)) return;
      if (e.code === "Space" || e.key === " ") {
        e.preventDefault();
        if (!e.repeat) stop();
      }
    };
    const up = (e) => { if (inHw(e)) return; if (e.code === "Space" || e.key === " ") e.preventDefault(); };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, [stop]);

  const running = phase === "running";
  const acc = stats.attempts ? Math.round((stats.hits / stats.attempts) * 100) : 0;

  return (
    <>
    <div className="rr">
      <style>{css}</style>
      <div className="wrap">
        <header>
          <h1>REACTION RUSH</h1>
          <p className="sub">10 LED Challenge: hit STOP when the lit LED matches the target</p>
        </header>

        <section className="panel">
          <div className="leds" aria-label="LED row">
            {Array.from({ length: N }, (_, i) => {
              const n = i + 1, c = COLORS[i], on = running && active === n || (phase === "result" && result && result.hitLed === n);
              const isT = (running || phase === "result") && target === n;
              return (
                <div className="slot" key={n}>
                  <div className="tag">{isT ? "TARGET" : ""}</div>
                  <div className={`led${on ? " on" : ""}${isT && !on ? " tgt" : ""}`}
                    style={on ? { background: c, boxShadow: `0 0 12px ${c}, 0 0 34px ${c}, inset 0 0 10px #fff8`, borderColor: c } : undefined}>
                    {n}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <section className="panel result" aria-live="polite">
          {phase === "idle" && <div className="info">Pick a target and speed, then press START.</div>}
          {running && <div className="info blink">Target is LED {target}. Press STOP (Spacebar) when it lights.</div>}
          {phase === "result" && result && (
            result.type === "win" ? (
              <>
                <div className="big win">WIN!</div>
                <div className="info">Reaction time <b style={{ color: "#fff" }}>{result.time} ms</b> · +{result.score} points</div>
              </>
            ) : (
              <>
                <div className="big miss">MISS</div>
                <div className="info">LED {result.hitLed} was lit, target was LED {target}. Try again.</div>
              </>
            )
          )}
        </section>

        <section className="panel" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <div className="lbl">Target LED</div>
            <div className="row">
              <button className={`chip${sel === "random" ? " sel" : ""}`} disabled={running} onClick={() => setSel("random")}>RANDOM</button>
              {Array.from({ length: N }, (_, i) => (
                <button key={i} className={`chip num${sel === i + 1 ? " sel" : ""}`} disabled={running} onClick={() => setSel(i + 1)}>{i + 1}</button>
              ))}
            </div>
          </div>
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div>
              <div className="lbl">LED speed</div>
              <div className="row">
                {Object.keys(SPEEDS).map((s) => (
                  <button key={s} className={`chip${speed === s ? " sel" : ""}`} disabled={running} onClick={() => setSpeed(s)}>{s}</button>
                ))}
              </div>
            </div>
            <div>
              <div className="lbl">Sound</div>
              <button className={`chip${sound ? " sel" : ""}`} onClick={() => setSound((v) => !v)} aria-pressed={sound}>{sound ? "ON" : "OFF"}</button>
            </div>
          </div>
          <div className="row" style={{ justifyContent: "center", paddingTop: 4 }}>
            <button className="btn start" disabled={running || phase === "result"} onClick={start}>START</button>
            <button className="btn stop" disabled={!running} onClick={stop}>STOP</button>
            <button className="btn again" disabled={phase !== "result"} onClick={start}>PLAY AGAIN</button>
            <button className="btn" onClick={reset}>RESET</button>
          </div>
        </section>

        <section className="panel">
          <div className="stats">
            <div className="stat"><b>{stats.attempts}</b><span>Attempts</span></div>
            <div className="stat"><b>{stats.hits}</b><span>Successful hits</span></div>
            <div className="stat"><b>{acc}%</b><span>Accuracy</span></div>
            <div className="stat"><b>{stats.best === null ? "--" : stats.best + " ms"}</b><span>Best reaction</span></div>
            <div className="stat"><b>{stats.score}</b><span>Score</span></div>
          </div>
        </section>

        <section className="panel">
          <div className="lbl">Circuit view: how the game works in hardware terms</div>
          <Circuit phase={phase} active={active} result={result && result.type} />
        </section>
      </div>
    </div>
    <HardwareSection game={{ active, running }} />
    </>
  );
}

/* ======================================================================
   FROM GAME TO REAL HARDWARE  (functional schematic, datasheet pinouts)
   ====================================================================== */
const hwCss = `
.hw{--slow:1;position:relative;color:#d7fff0;font-family:'Chakra Petch',system-ui,sans-serif;padding:72px 16px 96px;box-sizing:border-box;
 background:linear-gradient(rgba(0,255,150,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,150,.035) 1px,transparent 1px),radial-gradient(ellipse at 50% 0%,#0b2a22 0%,#04100d 70%);background-size:24px 24px,24px 24px,auto;border-top:2px solid #14523f}
.hw *{box-sizing:border-box}
.hw .in-wrap{max-width:1280px;margin:0 auto}
.hw h2{font-family:Orbitron,sans-serif;font-weight:800;font-size:clamp(24px,5vw,44px);margin:0 0 10px;color:#fff;letter-spacing:.04em;text-shadow:0 0 10px #29a8ff,0 0 28px #2dff8a55}
.hw .lead{color:#9fd8c6;max-width:760px;font-size:16px;line-height:1.6;margin:0 0 22px}
.hw .rv{opacity:0;transform:translateY(30px);transition:opacity .8s ease,transform .8s ease}
.hw .rv.in{opacity:1;transform:none}
.hw.calm .rv{opacity:1;transform:none;transition:none}
.hw .warn{border:1px solid #ffb02088;background:rgba(255,176,32,.07);border-radius:12px;padding:14px 16px;color:#ffe2a8;font-size:14px;line-height:1.55;margin-bottom:20px}
.hw .warn b{color:#ffb020}
.hw .cmp{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:28px}
@media(max-width:720px){.hw .cmp{grid-template-columns:1fr}}
.hw .card{background:rgba(6,20,15,.88);border:1px solid #14523f;border-radius:12px;padding:14px}
.hw .card h4{margin:0 0 4px;font-size:14px;color:#fff}
.hw .card p{margin:0 0 10px;font-size:12.5px;color:#8fc9b6}
.hw .strip{display:flex;gap:6px}
.hw .dot{flex:1;aspect-ratio:1;max-width:30px;border-radius:50%;background:#10211b;border:1px solid #1d4a3c;transition:background .1s,box-shadow .1s}
.hw .grid{display:grid;grid-template-columns:minmax(0,1fr);gap:24px;align-items:start}
.hw.wide .grid{grid-template-columns:minmax(0,1fr) 300px}
.hw.wide .stick{position:sticky;top:10px}
.hw .bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}
.hw .hb{font-family:Orbitron,sans-serif;font-size:12px;letter-spacing:.05em;cursor:pointer;border-radius:8px;border:1px solid #1d7a5c;background:#08211a;color:#bff5e0;padding:9px 13px;transition:all .15s}
.hw .hb:hover:not(:disabled){border-color:#2dff8a;color:#fff;box-shadow:0 0 12px #2dff8a55}
.hw .hb.go{background:#2dff8a;color:#00180b;border-color:#2dff8a}
.hw .hb.amb{background:#ffb020;color:#1a1000;border-color:#ffb020}
.hw .hb.on{background:#29a8ff;color:#00131f;border-color:#29a8ff}
.hw .hb:disabled{opacity:.35;cursor:not-allowed}
.hw .hb:focus-visible,.hw .ic:focus-visible{outline:2px solid #ffb020;outline-offset:2px}
.hw .board{position:relative;background:#041510;border:1px solid #14523f;border-radius:14px;box-shadow:0 0 30px rgba(41,168,255,.12) inset}
.hw .scroll{overflow-x:auto;padding:6px}
.hw svg.sch{display:block;width:100%;min-width:900px;height:auto}
.hw.wide svg.sch{max-height:calc(100vh - 130px)}
.hw svg text{font-family:'Chakra Petch',sans-serif}
.hw .sg{opacity:0;transform:translateY(12px);transition:opacity .8s ease,transform .8s ease}
.hw .sg.on{opacity:1;transform:none}
.hw .sg:not(.on){pointer-events:none}
.hw.calm .sg{transition:none}
.hw .ic{cursor:pointer;transition:transform .25s ease,filter .25s ease;transform-box:fill-box;transform-origin:center}
.hw:not(.calm) .ic:hover{transform:perspective(500px) rotateX(10deg) translateY(-3px) scale(1.03);filter:drop-shadow(0 10px 8px rgba(0,0,0,.7))}
.hw .body{fill:url(#pkg);stroke:#33454d;stroke-width:1.2;transition:stroke .2s,filter .2s}
.hw .ic.lit .body{stroke:#2dff8a;filter:drop-shadow(0 0 8px rgba(45,255,138,.55))}
.hw .ic.sel .body{stroke:#ffb020}
.hw .notch{fill:none;stroke:#4b6068;stroke-width:1.2}
.hw .pin{stroke:#aab4bc;stroke-width:3}.hw .pin.hot{stroke:#2dff8a}
.hw .pl{font-size:8px;fill:#8fd8c0}.hw .pl.hot{fill:#2dff8a;font-weight:700}
.hw .pn{font-size:7px;fill:#7b8f99}
.hw .nm{font-size:10px;fill:#d7fff0;font-weight:600}
.hw .nl{font-size:8px;fill:#58b8ff}.hw .nl.hi{fill:#2dff8a;font-weight:700}
.hw .w{fill:none;stroke:#29a8ff;stroke-width:1.5;opacity:.7}
.hw .wf{fill:none;stroke:#2dff8a;stroke-width:2.4;stroke-dasharray:5 9;filter:drop-shadow(0 0 3px #2dff8a);animation:hwflow calc(.7s*var(--slow)) linear infinite}
.hw .wf.clk{stroke:#ffb020;filter:drop-shadow(0 0 3px #ffb020)}
.hw.calm .wf{animation:none;stroke-dasharray:none}
@keyframes hwflow{to{stroke-dashoffset:-14}}
.hw .gl line,.hw .gl path{stroke:#8aa6a0;stroke-width:1.4;fill:none}
.hw .vc line{stroke:#ffb020;stroke-width:1.4}.hw .vc text{fill:#ffb020;font-size:8px}
.hw .comp{fill:#16222a;stroke:#ffb020;stroke-width:1.2}
.hw .ct{fill:#ffb020;font-size:8px}
.hw .tx{fill:#8fc9b6;font-size:8.5px}
.hw .big{fill:#fff;font-size:15px;font-weight:700;font-family:Orbitron,sans-serif}
.hw .sw{fill:#08211a;stroke:#29a8ff;stroke-width:1.5;cursor:pointer;transition:all .15s}
.hw .sw.on{fill:#ffb020;stroke:#ffb020;filter:drop-shadow(0 0 6px #ffb020)}
.hw .led{fill:#10211b;stroke:#3b6a5c;stroke-width:1.5;transition:fill .1s}
.hw .insp{position:absolute;right:10px;top:10px;width:min(330px,calc(100% - 20px));max-height:70%;overflow:auto;background:rgba(4,16,13,.96);border:1px solid #ffb020;border-radius:12px;padding:14px;font-size:12.5px;z-index:3;box-shadow:0 12px 40px rgba(0,0,0,.6)}
@media(max-width:1239px){.hw .insp{position:static;width:100%;max-height:none;margin:8px 0 0;box-shadow:none}}
.hw .insp h4{margin:0 0 6px;color:#ffb020;font-size:15px}.hw .insp p{margin:0 0 8px;color:#bfe9da}
.hw .insp table{width:100%;border-collapse:collapse}.hw .insp td{padding:2px 4px;border-top:1px solid #14523f;vertical-align:top;color:#a9dccb}.hw .insp td:first-child{color:#2dff8a;white-space:nowrap}
.hw .insp .x{position:absolute;right:8px;top:6px;background:none;border:0;color:#fff;font-size:20px;cursor:pointer}
.hw .step{min-height:46vh;display:flex;flex-direction:column;justify-content:center;border-left:3px solid #14523f;padding:6px 0 6px 16px;margin-bottom:18px;transition:border-color .4s,opacity .4s;opacity:.45}
.hw .step.cur{border-color:#2dff8a;opacity:1}
.hw:not(.wide) .step{min-height:0;opacity:1}
.hw .step h3{margin:0 0 6px;font-family:Orbitron,sans-serif;font-size:15px;color:#fff}
.hw .step p{margin:0;font-size:13.5px;line-height:1.6;color:#a9dccb}
.hw .sec{margin-top:56px}
.hw .sec h3{font-family:Orbitron,sans-serif;font-size:20px;margin:0 0 14px;color:#fff}
.hw .tw{overflow-x:auto;border:1px solid #14523f;border-radius:12px}
.hw table.ct2{width:100%;min-width:760px;border-collapse:collapse;font-size:13px}
.hw .ct2 th{background:#08211a;color:#2dff8a;text-align:left;padding:10px;font-family:Orbitron,sans-serif;font-size:11px;letter-spacing:.05em}
.hw .ct2 td{padding:10px;border-top:1px solid #12392d;color:#bfe9da;vertical-align:top}
.hw .ct2 td:first-child{color:#ffb020;font-weight:600;white-space:nowrap}
.hw ol.flow{margin:0;padding:0;list-style:none;counter-reset:s;display:grid;gap:10px}
.hw ol.flow li{counter-increment:s;background:rgba(6,20,15,.88);border:1px solid #14523f;border-radius:10px;padding:12px 14px 12px 52px;position:relative;color:#bfe9da;font-size:14px;line-height:1.55}
.hw ol.flow li:before{content:counter(s);position:absolute;left:12px;top:10px;width:28px;height:28px;border-radius:50%;background:#2dff8a;color:#00180b;font-family:Orbitron,sans-serif;font-weight:800;display:flex;align-items:center;justify-content:center}
`;

const ICDEF = {
  u1: { x: 330, y: 48, w: 70, p: 26, n: 8, ref: "U1", name: "NE555", pins: ["GND", "TRIG", "OUT", "RESET", "CTRL", "THR", "DIS", "VCC"] },
  u2: { x: 110, y: 48, w: 90, p: 16, n: 16, ref: "U2", name: "CD4017", pins: ["Q5", "Q1", "Q0", "Q2", "Q6", "Q7", "Q3", "VSS", "Q8", "Q4", "Q9", "CO", "INH", "CLK", "RST", "VDD"] },
  u3: { x: 400, y: 530, w: 86, p: 16, n: 14, ref: "U3", name: "74HC08", pins: ["1A", "1B", "1Y", "2A", "2B", "2Y", "GND", "3Y", "3A", "3B", "4Y", "4A", "4B", "VCC"] },
  u6: { x: 640, y: 530, w: 86, p: 16, n: 14, ref: "U6", name: "74HC32", pins: ["1A", "1B", "1Y", "2A", "2B", "2Y", "GND", "3Y", "3A", "3B", "4Y", "4A", "4B", "VCC"] },
  u9: { x: 760, y: 700, w: 84, p: 16, n: 14, ref: "U9", name: "74HC74", pins: ["1CLR", "1D", "1CLK", "1PRE", "1Q", "1Q\u0305", "GND", "2Q\u0305", "2Q", "2PRE", "2CLK", "2D", "2CLR", "VCC"] },
  u10: { x: 400, y: 700, w: 86, p: 16, n: 14, ref: "U10", name: "74HC14", pins: ["1A", "1Y", "2A", "2Y", "3A", "3Y", "GND", "4Y", "4A", "5Y", "5A", "6Y", "6A", "VCC"] },
};
const NETS = {
  u1: { 1: "GND", 4: "+5V" },
  u2: { 8: "GND", 16: "+5V", 12: "NC", 13: "HOLD", 15: "RST" },
  u3: { 1: "Q0", 2: "T0", 3: "M0", 4: "Q1", 5: "T1", 6: "M1", 7: "GND", 8: "M2", 9: "Q2", 10: "T2", 11: "M3", 12: "Q3", 13: "T3", 14: "+5V" },
  u6: { 1: "M0", 2: "M1", 3: "O1", 4: "M2", 5: "M3", 6: "O2", 7: "GND", 8: "O3", 9: "M4", 10: "M5", 11: "O4", 12: "M6", 13: "M7", 14: "+5V" },
  u9: { 1: "/RST", 3: "STOP", 4: "+5V", 7: "GND", 8: "NC", 9: "HOLD", 10: "+5V", 11: "STOP", 12: "+5V", 13: "/RST", 14: "+5V" },
  u10: { 2: "STOP", 4: "RST", 5: "GND", 6: "NC", 7: "GND", 8: "NC", 9: "GND", 10: "NC", 11: "GND", 12: "NC", 13: "GND", 14: "+5V" },
};
const INFO = {
  u1: { fn: "Astable clock. With R1 = 1 k\u03A9, R2 = 100 k\u03A9, C1 = 1 \u00B5F the output is about 7 Hz (f \u2248 1.44 / ((R1 + 2\u00B7R2)\u00B7C1)). Pin 3 clocks the CD4017.",
    c: ["GND", "Tied to pin 6", "Clock \u2192 U2 pin 14", "+5V (active-low reset unused)", "10 nF to GND", "R2 / C1 junction, tied to pin 2", "R1 / R2 junction", "+5V"] },
  u2: { fn: "Decade counter. Each clock pulse moves a single high output from Q0 to Q1 \u2026 Q9 and back to Q0, in fixed order. It cannot produce a random sequence.",
    c: ["LED6 resistor \u00B7 U4 pin 4", "LED2 resistor \u00B7 U3 pin 4", "LED1 resistor \u00B7 U3 pin 1", "LED3 resistor \u00B7 U3 pin 9", "LED7 resistor \u00B7 U4 pin 9", "LED8 resistor \u00B7 U4 pin 12", "LED4 resistor \u00B7 U3 pin 12", "GND", "LED9 resistor \u00B7 U5 pin 1", "LED5 resistor \u00B7 U4 pin 1", "LED10 resistor \u00B7 U5 pin 4", "Not connected", "HOLD \u2190 U9 pin 9", "U1 pin 3 (NE555 OUT)", "RST \u2190 U10 pin 4", "+5V"] },
  u3: { fn: "Quad AND. Each gate outputs Mn = Qn AND Tn, so it is high only when the lit LED is the selected target. U4 (Q4\u2013Q7) uses the same pin map; U5 handles Q8, Q9 and the MISS gate.",
    c: ["Q0 (U2 pin 3)", "T0 (selector)", "M0 \u2192 U6 pin 1", "Q1 (U2 pin 2)", "T1", "M1 \u2192 U6 pin 2", "GND", "M2 \u2192 U6 pin 4", "Q2 (U2 pin 4)", "T2", "M3 \u2192 U6 pin 5", "Q3 (U2 pin 7)", "T3", "+5V"] },
  u6: { fn: "Quad OR, first level of the OR tree: combines M0\u2013M7 into O1\u2013O4. U7 and U8 (also 74HC32) finish the tree and produce MATCH on U8 pin 3.",
    c: ["M0 \u2190 U3 pin 3", "M1 \u2190 U3 pin 6", "O1 \u2192 U7 pin 4", "M2 \u2190 U3 pin 8", "M3 \u2190 U3 pin 11", "O2 \u2192 U7 pin 5", "GND", "O3 \u2192 U7 pin 9", "M4 \u2190 U4 pin 3", "M5 \u2190 U4 pin 6", "O4 \u2192 U7 pin 10", "M6 \u2190 U4 pin 8", "M7 \u2190 U4 pin 11", "+5V"] },
  u9: { fn: "Dual D flip-flop. Flip-flop 1 samples MATCH on the STOP edge (Q = WIN). Flip-flop 2 (D = +5V) latches HOLD, which inhibits the CD4017 clock so the LED freezes.",
    c: ["/RST", "D1 \u2190 MATCH (U8 pin 3)", "CLK1 \u2190 STOP (U10 pin 2)", "+5V", "Q1 \u2192 WIN lamp", "/Q1 \u2192 U5 pin 10 (MISS gate)", "GND", "Not connected", "Q2 = HOLD \u2192 U2 pin 13, U5 pin 9", "+5V", "CLK2 \u2190 STOP", "D2 = +5V", "/RST", "+5V"] },
  u10: { fn: "Hex Schmitt-trigger inverter. Cleans up the bouncing STOP and RESET push buttons. Unused inputs are tied to GND.",
    c: ["STOP button node (10 k\u03A9 to +5V, button to GND)", "STOP \u2192 U9 pins 3, 11", "RESET button node = /RST \u2192 U9 pins 1, 13", "RST \u2192 U2 pin 15", "GND", "Not connected", "GND", "Not connected", "GND", "Not connected", "GND", "Not connected", "GND", "+5V"] },
};
const QPIN = [3, 2, 4, 7, 10, 1, 5, 6, 9, 11];
const XV = { 1: 24, 2: 34, 3: 44, 4: 54, 5: 64, 6: 74, 7: 84, 11: 250, 10: 240, 9: 230 };
const GATE = [[1, 2, 3], [4, 5, 6], [9, 10, 8], [12, 13, 11]];

const pinXY = (ic, p) => {
  const half = ic.n / 2, left = p <= half, k = left ? p - 1 : ic.n - p;
  return { x: left ? ic.x - 10 : ic.x + ic.w + 10, y: ic.y + 14 + k * ic.p, left };
};

function Wire({ d, on, clk }) {
  return (<g><path d={d} className="w" />{on && <path d={d} className={"wf" + (clk ? " clk" : "")} />}</g>);
}
function Sg({ on, d = 0, children }) {
  return <g className={"sg" + (on ? " on" : "")} style={{ transitionDelay: on ? d + "ms" : "0ms" }}>{children}</g>;
}
function Term({ x, y, left, net, hi }) {
  const d = left ? -1 : 1;
  if (net === "GND") return (<g className="gl"><line x1={x} y1={y} x2={x + d * 8} y2={y} /><line x1={x + d * 8} y1={y - 6} x2={x + d * 8} y2={y + 6} /><line x1={x + d * 11} y1={y - 4} x2={x + d * 11} y2={y + 4} /><line x1={x + d * 14} y1={y - 2} x2={x + d * 14} y2={y + 2} /></g>);
  if (net === "+5V") return (<g className="vc"><line x1={x} y1={y} x2={x + d * 8} y2={y} /><line x1={x + d * 8} y1={y - 6} x2={x + d * 8} y2={y + 6} /><text x={x + d * 8} y={y - 9} textAnchor="middle">+5V</text></g>);
  if (net === "NC") return (<g className="gl"><line x1={x} y1={y} x2={x + d * 5} y2={y} /><path d={`M${x + d * 5},${y - 3} l${d * 6},6 m0,-6 l${-d * 6},6`} /></g>);
  return (<g><line x1={x} y1={y} x2={x + d * 3} y2={y} className="w" /><text className={"nl" + (hi ? " hi" : "")} x={x + d * 5} y={y + 3} textAnchor={left ? "end" : "start"}>{net}</text></g>);
}
function IC({ id, sel, lit, hiPins = [], onPick, hiNet }) {
  const ic = ICDEF[id], half = ic.n / 2, h = (half - 1) * ic.p + 28, nets = NETS[id] || {};
  const pins = [];
  for (let p = 1; p <= ic.n; p++) {
    const { x, y, left } = pinXY(ic, p), bx = left ? ic.x : ic.x + ic.w, hot = hiPins.includes(p);
    pins.push(
      <g key={p}>
        <line x1={bx} y1={y} x2={x} y2={y} className={"pin" + (hot ? " hot" : "")} />
        <text className="pn" x={left ? ic.x - 3 : ic.x + ic.w + 3} y={y - 3} textAnchor={left ? "end" : "start"}>{p}</text>
        <text className={"pl" + (hot ? " hot" : "")} x={left ? ic.x + 5 : ic.x + ic.w - 5} y={y + 3} textAnchor={left ? "start" : "end"}>{ic.pins[p - 1]}</text>
        {nets[p] && <Term x={x} y={y} left={left} net={nets[p]} hi={hiNet(nets[p])} />}
      </g>
    );
  }
  return (
    <g className={"ic" + (lit ? " lit" : "") + (sel ? " sel" : "")} role="button" tabIndex={0} aria-label={`${ic.ref} ${ic.name}: inspect`}
      onClick={() => onPick(id)} onKeyDown={(e) => { if (e.key === "Enter") onPick(id); }}>
      {pins}
      <rect className="body" x={ic.x} y={ic.y} width={ic.w} height={h} rx="4" />
      <path className="notch" d={`M${ic.x + ic.w / 2 - 6},${ic.y} a6,6 0 0 0 12,0`} />
      <circle cx={ic.x + 7} cy={ic.y + 6} r="2" fill="#4b6068" />
      <text className="nm" x={ic.x} y={ic.y - 8}>{ic.ref} · {ic.name}</text>
    </g>
  );
}
const Rv = ({ x, y, h = 24, label, lx }) => (<g><rect className="comp" x={x - 6} y={y} width="12" height={h} rx="2" />{label && <text className="ct" x={lx ?? x + 10} y={y + h / 2 + 3}>{label}</text>}</g>);
const GndSym = ({ x, y }) => (<g className="gl"><line x1={x - 8} y1={y} x2={x + 8} y2={y} /><line x1={x - 5} y1={y + 4} x2={x + 5} y2={y + 4} /><line x1={x - 2} y1={y + 8} x2={x + 2} y2={y + 8} /></g>);

function HardwareSection({ game }) {
  const root = useRef(null);
  const mq = (q) => { try { return window.matchMedia(q).matches; } catch (e) { return false; } };
  const [calm, setCalm] = useState(() => mq("(prefers-reduced-motion: reduce)"));
  const [wide, setWide] = useState(() => mq("(min-width:1240px)"));
  const [stage, setStage] = useState(1);
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(5);
  const [running, setRunning] = useState(false);
  const [held, setHeld] = useState(false);
  const [win, setWin] = useState(false);
  const [slow, setSlow] = useState(false);
  const [pick, setPick] = useState(null);
  const countRef = useRef(0), targetRef = useRef(5), heldRef = useRef(false);
  countRef.current = count; targetRef.current = target; heldRef.current = held;

  useEffect(() => {
    let m; try { m = window.matchMedia("(min-width:1240px)"); } catch (e) { return; }
    const f = () => setWide(m.matches);
    m.addEventListener ? m.addEventListener("change", f) : m.addListener(f);
    return () => { m.removeEventListener ? m.removeEventListener("change", f) : m.removeListener(f); };
  }, []);

  // scroll-triggered reveals + stage tracking
  useEffect(() => {
    const el = root.current; if (!el || typeof IntersectionObserver === "undefined") { el && el.querySelectorAll(".rv").forEach((n) => n.classList.add("in")); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12 });
    el.querySelectorAll(".rv").forEach((n) => io.observe(n));
    const so = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) setStage(+e.target.dataset.stage); }), { rootMargin: "-40% 0px -40% 0px" });
    el.querySelectorAll("[data-stage]").forEach((n) => so.observe(n));
    return () => { io.disconnect(); so.disconnect(); };
  }, []);

  // clock: one timer, cleaned up on pause / latch / unmount
  useEffect(() => {
    if (!running || held) return;
    const id = setInterval(() => setCount((c) => (c + 1) % 10), slow ? 1000 : 380);
    return () => clearInterval(id);
  }, [running, held, slow]);

  const start = () => { if (!heldRef.current) setRunning(true); };
  const pause = () => setRunning(false);
  const reset = () => { setRunning(false); setHeld(false); setWin(false); setCount(0); };
  const stopLatch = () => {
    if (heldRef.current) return;
    heldRef.current = true; setHeld(true); setRunning(false); setWin(countRef.current === targetRef.current);
  };

  const q = (i) => count === i, t = (i) => target === i, m = (i) => q(i) && t(i);
  const O1 = m(0) || m(1), O2 = m(2) || m(3), O3 = m(4) || m(5), O4 = m(6) || m(7), O5 = m(8) || m(9);
  const O6 = O1 || O2, O7 = O3 || O4, O8 = O6 || O7, match = count === target;
  const sig = { O1, O2, O3, O4, O5, O6, O7, O8, MATCH: match, HOLD: held, STOP: held };
  const hiNet = (n) => { const r = n.match(/^([QTM])(\d)$/); if (r) { const i = +r[2]; return r[1] === "Q" ? q(i) : r[1] === "T" ? t(i) : m(i); } return !!sig[n]; };
  const u3hi = []; for (let i = 0; i < 4; i++) { if (q(i)) u3hi.push(GATE[i][0]); if (t(i)) u3hi.push(GATE[i][1]); if (m(i)) u3hi.push(GATE[i][2]); }
  const S = (n) => (calm || !wide ? true : stage >= n);
  const missLamp = held && !win;
  const status = held ? (win ? "WIN LATCHED" : "MISS LATCHED") : running ? "CLOCK RUNNING" : "CLOCK PAUSED";
  const I = pick && { ...ICDEF[pick], ...INFO[pick] };
  const COL = COLORS;
  const stepTxt = [
    ["1 · The clock", "An NE555 wired as an astable oscillator produces a steady pulse train (about 7 Hz here). Its OUT pin 3 drives the CLK input, pin 14, of the CD4017."],
    ["2 · The counter and LEDs", "Every pulse moves the single high output of the CD4017 one step along Q0 \u2192 Q9. Each output drives one LED through its own resistor. The chase is sequential, not random."],
    ["3 · The comparison", "A 10-position switch drives exactly one target line Tn high. Ten AND gates compute Mn = Qn AND Tn, and an OR tree collapses M0\u2013M9 into one MATCH signal."],
    ["4 · The latch", "STOP is cleaned up by the 74HC14 and clocks the 74HC74. One flip-flop stores MATCH as WIN; the other raises HOLD, which inhibits the CD4017 so the LED freezes."],
  ];

  return (
    <section className={"hw" + (calm ? " calm" : "") + (wide ? " wide" : "")} ref={root} style={{ "--slow": slow ? 3 : 1 }} aria-labelledby="hw-title">
      <style>{hwCss}</style>
      <div className="in-wrap">
        <div className="bar rv" style={{ justifyContent: "space-between" }}>
          <span style={{ color: "#2dff8a", fontFamily: "Orbitron,sans-serif", fontSize: 12, letterSpacing: ".1em" }}>ELECTRONICS LAB</span>
          <button className={"hb" + (calm ? " on" : "")} aria-pressed={calm} onClick={() => setCalm((v) => !v)}>REDUCE MOTION: {calm ? "ON" : "OFF"}</button>
        </div>
        <h2 id="hw-title" className="rv">FROM GAME TO REAL HARDWARE</h2>
        <p className="lead rv">The same idea built from classic logic ICs: a clock, a decade counter, ten LEDs, a comparator and a latch. Scroll to watch the circuit assemble, then run it.</p>

        <div className="warn rv">
          <b>Functional schematic, not a fabrication-ready design.</b> Pin numbers follow the standard datasheet pinouts of the NE555, CD4017B, 74HC08, 74HC32, 74HC74 and 74HC14. Decoupling capacitors, LED current budget and PCB layout are not included, and the repeated gate packages (U4, U5, U7, U8) are described rather than drawn. Check every pin against the manufacturer datasheet before building.
        </div>

        <div className="cmp rv">
          <div className="card"><h4>Website game: software, random</h4><p>JavaScript picks a random LED each tick. This is the game above.</p>
            <div className="strip">{Array.from({ length: 10 }, (_, i) => { const on = game.running && game.active === i + 1; return <span key={i} className="dot" style={on ? { background: COL[i], boxShadow: `0 0 12px ${COL[i]}`, borderColor: COL[i] } : undefined} />; })}</div></div>
          <div className="card"><h4>Hardware demo: CD4017, sequential</h4><p>The counter can only step Q0 → Q1 → … → Q9 → Q0. It is a chase, not a random sequence.</p>
            <div className="strip">{Array.from({ length: 10 }, (_, i) => { const on = q(i); return <span key={i} className="dot" style={on ? { background: COL[i], boxShadow: `0 0 12px ${COL[i]}`, borderColor: COL[i] } : undefined} />; })}</div></div>
        </div>

        <div className="grid">
          <div className="stick rv">
            <div className="bar">
              <button className="hb go" onClick={start} disabled={running || held}>START CLOCK</button>
              <button className="hb" onClick={pause} disabled={!running}>PAUSE</button>
              <button className="hb amb" onClick={stopLatch} disabled={held}>STOP (LATCH)</button>
              <button className="hb" onClick={reset}>RESET</button>
              <button className={"hb" + (slow ? " on" : "")} aria-pressed={slow} onClick={() => setSlow((v) => !v)}>SLOW MOTION</button>
            </div>
            <div className="board">
              <div className="scroll">
                <svg className="sch" viewBox="0 0 1120 840" role="img" aria-label="Functional schematic of the 10 LED reaction game built from NE555, CD4017, 74HC08, 74HC32, 74HC74 and 74HC14">
                  <defs><linearGradient id="pkg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2a3238" /><stop offset=".5" stopColor="#12171b" /><stop offset="1" stopColor="#0a0d10" /></linearGradient></defs>

                  {/* STAGE 1: clock */}
                  <Sg on={S(1)}>
                    <IC id="u2" sel={pick === "u2"} lit={running} hiPins={running || count >= 0 ? [QPIN[count]] : []} onPick={setPick} hiNet={hiNet} />
                    <IC id="u1" sel={pick === "u1"} lit={running} hiPins={running ? [3] : []} onPick={setPick} hiNet={hiNet} />
                    <Wire d="M320,114 H266 V94 H210" on={running} clk />
                    <text className="nl" x="272" y="106">CLK</text>
                    <Wire d="M320,88 H300 V176 H520 V114 H480" />
                    <Wire d="M410,62 H426 V40 H480" /><text className="ct" x="486" y="43">+5V</text>
                    <Wire d="M480,40 V56" /><Rv x={480} y={56} label="R1 1k" lx={492} /><Wire d="M480,80 V88" />
                    <Wire d="M410,88 H480" /><circle cx="480" cy="88" r="2.5" fill="#29a8ff" />
                    <Wire d="M480,88 V94" /><Rv x={480} y={94} h={14} label="R2 100k" lx={492} /><Wire d="M480,108 V114" />
                    <Wire d="M410,114 H480" /><circle cx="480" cy="114" r="2.5" fill="#29a8ff" />
                    <Wire d="M480,114 V142" /><line className="w" x1="472" y1="142" x2="488" y2="142" /><line className="w" x1="472" y1="147" x2="488" y2="147" /><Wire d="M480,147 V156" /><GndSym x={480} y={156} /><text className="ct" x="494" y="150">C1 1µF</text>
                    <Wire d="M410,140 H430 V150" /><line className="w" x1="422" y1="150" x2="438" y2="150" /><line className="w" x1="422" y1="155" x2="438" y2="155" /><Wire d="M430,155 V162" /><GndSym x={430} y={162} /><text className="ct" x="396" y="168" >C2 10nF</text>
                    <text className="big" x="640" y="76" style={{ fill: held ? (win ? "#2dff8a" : "#ff4b6e") : "#fff" }}>{status}</text>
                    <text className="tx" x="640" y="98">COUNT: Q{count} → LED {count + 1}</text>
                    <text className="tx" x="640" y="112">TARGET: T{target} → LED {target + 1}</text>
                    <text className="tx" x="640" y="126" style={{ fill: match ? "#2dff8a" : "#ff8aa0", fontWeight: 700 }}>MATCH = {match ? "1" : "0"}</text>
                    <line x1="640" y1="150" x2="670" y2="150" className="w" /><text className="tx" x="676" y="153">idle wire</text>
                    <line x1="640" y1="164" x2="670" y2="164" stroke="#2dff8a" strokeWidth="2.4" /><text className="tx" x="676" y="167">high signal</text>
                    <line x1="640" y1="178" x2="670" y2="178" stroke="#ffb020" strokeWidth="2.4" /><text className="tx" x="676" y="181">clock pulses</text>
                  </Sg>

                  {/* STAGE 2: Q0-Q9 -> resistors -> LEDs */}
                  <Sg on={S(2)} d={150}>
                    {Array.from({ length: 10 }, (_, i) => {
                      const LX = 140 + i * 88, ly = 214 + (9 - i) * 12, pt = pinXY(ICDEF.u2, QPIN[i]), on = q(i);
                      return (
                        <g key={i}>
                          <Wire d={`M${pt.x},${pt.y} H${XV[QPIN[i]]} V${ly} H${LX} V352`} on={on} />
                          <text className={"nl" + (on ? " hi" : "")} x={LX - 4} y={ly - 2} textAnchor="end">Q{i}</text>
                          <Rv x={LX} y={352} label="1k" />
                          <Wire d={`M${LX},376 V393`} on={on} />
                          <circle className="led" cx={LX} cy="404" r="11" style={on ? { fill: COL[i], filter: `drop-shadow(0 0 9px ${COL[i]})` } : undefined} />
                          <text x={LX} y="408" textAnchor="middle" className="tx" style={{ fill: on ? "#000" : "#8fc9b6", fontWeight: 700 }}>{i + 1}</text>
                          <Wire d={`M${LX},415 V432`} on={on} /><GndSym x={LX} y={432} />
                          <text className="tx" x={LX} y="456" textAnchor="middle">LED{i + 1}</text>
                        </g>
                      );
                    })}
                  </Sg>

                  {/* STAGE 3: target selector + comparison */}
                  <Sg on={S(3)} d={150}>
                    <text className="tx" x="34" y="476">10-position target selector (T0–T9)</text>
                    <line className="w" x1="34" y1="490" x2="304" y2="490" /><text className="ct" x="28" y="493" textAnchor="end">+5V</text>
                    {Array.from({ length: 10 }, (_, i) => {
                      const x = 34 + i * 30, on = t(i);
                      return (
                        <g key={i} role="button" tabIndex={0} aria-label={`Select target LED ${i + 1}`} aria-pressed={on} style={{ cursor: "pointer" }}
                          onClick={() => setTarget(i)} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setTarget(i); } }}>
                          <Wire d={`M${x},490 V511`} on={on} />
                          <circle className={"sw" + (on ? " on" : "")} cx={x} cy="520" r="9" />
                          <text x={x} y="523" textAnchor="middle" className="tx" style={{ fill: on ? "#000" : "#bff5e0", fontWeight: 700 }}>{i + 1}</text>
                          <Wire d={`M${x},529 V538`} on={on} />
                          <text className={"nl" + (on ? " hi" : "")} x={x} y="548" textAnchor="middle">T{i}</text>
                        </g>
                      );
                    })}
                    <text className="tx" x="34" y="568">10 kΩ pull-downs hold unselected Tn low</text>
                    <text className="tx" x="34" y="580">Click a position to choose the target</text>
                    <IC id="u3" sel={pick === "u3"} lit={m(0) || m(1) || m(2) || m(3)} hiPins={u3hi} onPick={setPick} hiNet={hiNet} />
                    <IC id="u6" sel={pick === "u6"} lit={match} onPick={setPick} hiNet={hiNet} />
                    {["U4 (74HC08): Q4–Q7", "× T4–T7 → M4–M7", "U5 (74HC08): Q8, Q9", "→ M8, M9 + MISS gate", "U7, U8 (74HC32):", "OR tree → MATCH"].map((s, i) => <text key={i} className="tx" x="520" y={556 + i * 13}>{s}</text>)}
                    <text className={"nl" + (O8 ? " hi" : "")} x="824" y="580" textAnchor="end">O8</text>
                    <text className={"nl" + (O5 ? " hi" : "")} x="824" y="596" textAnchor="end">O5</text>
                    <rect className="comp" x="830" y="568" width="44" height="34" rx="5" style={match ? { stroke: "#2dff8a", filter: "drop-shadow(0 0 6px #2dff8a)" } : undefined} />
                    <text className="ct" x="852" y="589" textAnchor="middle">≥1</text>
                    <text className="tx" x="852" y="616" textAnchor="middle">U8A pins 1,2 → 3</text>
                    <text className={"nl" + (match ? " hi" : "")} x="880" y="578">MATCH</text>
                  </Sg>

                  {/* STAGE 4: buttons, schmitt conditioning, latch, lamps */}
                  <Sg on={S(4)} d={150}>
                    <IC id="u10" sel={pick === "u10"} lit={held} hiPins={held ? [2] : []} onPick={setPick} hiNet={hiNet} />
                    <IC id="u9" sel={pick === "u9"} lit={held} hiPins={held ? [win ? 5 : 6, 9] : []} onPick={setPick} hiNet={hiNet} />
                    {/* STOP button node -> U10 pin 1 */}
                    <Wire d="M290,714 H390" /><Wire d="M290,714 V708" /><Rv x={290} y={692} h={16} label="10k" lx={304} /><Wire d="M290,692 V686" /><text className="ct" x="290" y="682" textAnchor="middle">+5V</text>
                    <Wire d="M350,714 V705" /><circle className={"sw" + (held ? " on" : "")} cx="350" cy="697" r="8" role="button" tabIndex={0} aria-label="STOP push button" onClick={stopLatch} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); stopLatch(); } }} />
                    <Wire d="M350,689 V682" /><GndSym x={350} y={678} /><text className="ct" x="338" y="700" textAnchor="end">STOP</text>
                    {/* RESET button node -> U10 pin 3 */}
                    <Wire d="M290,746 H390" /><Wire d="M290,746 V752" /><Rv x={290} y={752} h={16} label="10k" lx={304} /><Wire d="M290,768 V776" /><text className="ct" x="290" y="788" textAnchor="middle">+5V</text>
                    <Wire d="M350,746 V755" /><circle className="sw" cx="350" cy="763" r="8" role="button" tabIndex={0} aria-label="RESET push button" onClick={reset} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); reset(); } }} />
                    <Wire d="M350,771 V778" /><GndSym x={350} y={780} /><text className="ct" x="338" y="766" textAnchor="end">RESET</text>
                    <text className="tx" x="246" y="730" textAnchor="end">optional 100 nF</text><text className="tx" x="246" y="741" textAnchor="end">debounce to GND</text>
                    {/* MATCH -> U9 pin 2 (D1) */}
                    <Wire d="M874,585 H900 V670 H700 V730 H750" on={match} />
                    {/* WIN lamp from Q1 (pin 5) */}
                    <Wire d="M750,778 H738" on={win} /><rect className="comp" x="720" y="772" width="18" height="12" rx="2" /><Wire d="M720,778 H708" on={win} />
                    <circle className="led" cx="698" cy="778" r="9" style={win ? { fill: "#2dff8a", filter: "drop-shadow(0 0 9px #2dff8a)" } : undefined} /><Wire d="M689,778 H680" on={win} /><g transform="rotate(90 678 778)"><GndSym x={678} y={778} /></g>
                    <text className="tx" x="698" y="760" textAnchor="middle">WIN</text>
                    {/* MISS lamp: HOLD AND /Q1 (U5 gate 3) */}
                    <Wire d="M750,794 H676" on={missLamp} />
                    <rect className="comp" x="640" y="786" width="36" height="26" rx="4" /><text className="ct" x="658" y="802" textAnchor="middle">&amp;</text>
                    <Wire d="M676,806 H690" on={held} /><text className={"nl" + (held ? " hi" : "")} x="692" y="809">HOLD</text>
                    <text className="tx" x="658" y="824" textAnchor="middle">U5C pins 9,10 → 8</text>
                    <Wire d="M640,799 H624" on={missLamp} /><rect className="comp" x="606" y="793" width="18" height="12" rx="2" /><Wire d="M606,799 H592" on={missLamp} />
                    <circle className="led" cx="582" cy="799" r="9" style={missLamp ? { fill: "#ff2e63", filter: "drop-shadow(0 0 9px #ff2e63)" } : undefined} /><Wire d="M573,799 H564" on={missLamp} /><g transform="rotate(90 562 799)"><GndSym x={562} y={799} /></g>
                    <text className="tx" x="582" y="781" textAnchor="middle">MISS</text>
                  </Sg>
                </svg>
              </div>
              {I && (
                <div className="insp" role="dialog" aria-label={`${I.ref} details`}>
                  <button className="x" aria-label="Close" onClick={() => setPick(null)}>×</button>
                  <h4>{I.ref} · {I.name} ({I.n}-pin DIP)</h4>
                  <p>{I.fn}</p>
                  <table><tbody>{I.pins.map((l, i) => <tr key={i}><td>{i + 1} {l}</td><td>{I.c[i]}</td></tr>)}</tbody></table>
                </div>
              )}
            </div>
            <p className="tx" style={{ fontSize: 12, color: "#7fb5a3", margin: "8px 2px 0" }}>Click any IC to inspect its pins. Click a selector position to change the target, or the STOP / RESET buttons in the schematic.</p>
          </div>

          <div>
            {stepTxt.map(([h, p], i) => (
              <div key={i} data-stage={i + 1} className={"step rv" + (stage === i + 1 ? " cur" : "")}><h3>{h}</h3><p>{p}</p></div>
            ))}
          </div>
        </div>

        <div className="sec rv">
          <h3>Connection table</h3>
          <div className="tw">
            <table className="ct2">
              <thead><tr><th>IC NAME</th><th>FUNCTION</th><th>INPUT CONNECTION</th><th>OUTPUT CONNECTION</th></tr></thead>
              <tbody>
                <tr><td>U1 NE555</td><td>Astable clock, about 7 Hz</td><td>+5V on pins 4, 8; R1 1 kΩ (+5V to pin 7); R2 100 kΩ (pin 7 to 6); pins 2 and 6 tied; C1 1 µF pin 6 to GND; 10 nF pin 5 to GND</td><td>Pin 3 → U2 pin 14</td></tr>
                <tr><td>U2 CD4017</td><td>Decade counter, one high output at a time, in fixed order</td><td>CLK pin 14 ← U1 pin 3; INH pin 13 ← HOLD (U9 pin 9); RST pin 15 ← U10 pin 4</td><td>Q0–Q9 → ten resistor + LED branches, and → AND gates in U3, U4, U5</td></tr>
                <tr><td>R + LED × 10</td><td>Show the active output</td><td>Q0–Q9 through a 1 kΩ resistor each</td><td>LED cathode to GND</td></tr>
                <tr><td>Target selector</td><td>10-position switch, one target line high</td><td>+5V common; 10 kΩ pull-downs</td><td>T0–T9 → AND gate B inputs</td></tr>
                <tr><td>U3, U4, U5 74HC08</td><td>Mn = Qn AND Tn; U5 gate 3 also forms MISS = HOLD AND /Q1</td><td>U3: Q0–Q3 on pins 1, 4, 9, 12 with T0–T3 on pins 2, 5, 10, 13. U4: Q4–Q7, T4–T7, same pins. U5: Q8, Q9, T8, T9 on gates 1–2</td><td>M0–M9 → U6, U7 OR inputs; U5 pin 8 → MISS lamp</td></tr>
                <tr><td>U6, U7, U8 74HC32</td><td>OR tree: M0–M9 → MATCH</td><td>U6: M0–M7 → O1–O4. U7: M8, M9 → O5; O1, O2 → O6; O3, O4 → O7; O6, O7 → O8</td><td>U8 pin 3: MATCH = O8 OR O5 → U9 pin 2</td></tr>
                <tr><td>U10 74HC14</td><td>Schmitt-trigger conditioning for the STOP and RESET buttons</td><td>Pin 1 STOP node; pin 3 RESET node (each 10 kΩ to +5V, button to GND)</td><td>Pin 2 STOP → U9 pins 3, 11; pin 4 RST → U2 pin 15</td></tr>
                <tr><td>U9 74HC74</td><td>Stores WIN and holds the counter</td><td>D1 (pin 2) = MATCH; CLK1 (pin 3) and CLK2 (pin 11) = STOP; D2 (pin 12) = +5V; CLR pins 1, 13 = /RST</td><td>Q1 pin 5 = WIN; /Q1 pin 6 → U5 pin 10; Q2 pin 9 = HOLD → U2 pin 13, U5 pin 9</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="sec rv">
          <h3>Signal flow, step by step</h3>
          <ol className="flow">
            <li>The NE555 free-runs and outputs a square wave on pin 3.</li>
            <li>Each rising edge on CD4017 pin 14 advances the single high output: Q0, Q1, Q2 … Q9, then back to Q0. The order never changes, so this is a chase, not the random mode of the website.</li>
            <li>The high output lights its LED through a current-limiting resistor.</li>
            <li>The same Qn goes to one input of an AND gate; the selector holds the matching Tn high.</li>
            <li>Mn goes high only when the lit position equals the target. The OR tree merges all ten Mn into one MATCH line.</li>
            <li>Pressing STOP produces one clean pulse through the 74HC14 (STOP is low at the button, high after inversion).</li>
            <li>On that rising edge U9 samples MATCH into Q1 (WIN) and sets Q2 (HOLD), which inhibits the CD4017 clock and freezes the LED.</li>
            <li>WIN lights if MATCH was 1; otherwise HOLD AND /Q1 lights MISS. RESET clears both flip-flops and returns the counter to Q0.</li>
          </ol>
        </div>
      </div>
    </section>
  );
}
